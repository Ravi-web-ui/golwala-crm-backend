import "dotenv/config";
import express from "express";
import cors from "cors";
import compression from "compression";
import rateLimit from "express-rate-limit";
import fs from "fs";
import path from "path";

import authRoutes           from "./routes/auth";
import leadsRoutes          from "./routes/leads";
import adminsRoutes         from "./routes/admins";
import filtersRoutes        from "./routes/filters";
import activitiesRoutes     from "./routes/activities";
import followupsRoutes      from "./routes/followups";
import calllogsRoutes       from "./routes/calllogs";
import reportsRoutes        from "./routes/reports";
import statusesRoutes       from "./routes/statuses";
import contactRoutes        from "./routes/contact";
import institutesRoutes     from "./routes/institutes";
import courseMappingsRoutes from "./routes/courseMappings";
import studentAdmissionsRoutes from "./routes/studentAdmissions";
import studentApplicationsView from "./routes/studentApplicationsView";
import siteConfigRoutes        from "./routes/siteConfig";
import galleryRoutes           from "./routes/gallery";
import eventsRoutes            from "./routes/events";
import websiteActivitiesRoutes from "./routes/websiteActivities";
import mediaLibraryRoutes      from "./routes/mediaLibrary";
import { prisma }       from "./db";

// ── Error log setup ───────────────────────────────────────────────────────────
const LOG_DIR  = path.join(process.cwd(), "logs");
const LOG_FILE = path.join(LOG_DIR, "error.log");
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

function writeLog(level: string, msg: string, meta?: any) {
  const line = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    msg,
    ...(meta ? { meta } : {}),
  }) + "\n";
  fs.appendFileSync(LOG_FILE, line);
  if (level === "ERROR") console.error(`[${level}] ${msg}`, meta || "");
  else console.log(`[${level}] ${msg}`);
}

process.on("uncaughtException", (err) => {
  writeLog("ERROR", "Uncaught Exception", { message: err.message, stack: err.stack });
  // Must exit on Prisma engine panic — Passenger will restart the process
  process.exit(1);
});
process.on("unhandledRejection", (err: any) => {
  writeLog("ERROR", "Unhandled Rejection", { message: err?.message, stack: err?.stack });
  process.exit(1);
});

// ── App ───────────────────────────────────────────────────────────────────────
const app = express();
const isProd = process.env.NODE_ENV === "production";

// Trust proxy - required for rate limiting behind reverse proxy (Hostinger)
app.set('trust proxy', 1);

// Gzip compress all responses
app.use(compression());

// Security headers
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("X-XSS-Protection", "1; mode=block");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  if (isProd) res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  next();
});

// CORS
const allowedOrigins = [
  process.env.FRONTEND_URL,
  process.env.ADMIN_URL,
  "https://golwalacollege.edu.in",
  "https://www.golwalacollege.edu.in",
  "https://admin.golwalacollege.edu.in",
  // dev
  "http://localhost:3000",
  "http://localhost:3001",
  "http://localhost:8080",
  "http://localhost:8081",
  "http://localhost:5173",
].filter(Boolean) as string[];

app.use(cors({
  origin: (origin, cb) => {
    // Allow requests with no origin (like mobile apps, curl, Postman)
    if (!origin) return cb(null, true);
    
    if (allowedOrigins.includes(origin)) {
      return cb(null, true);
    }
    
    writeLog("WARN", `CORS blocked: ${origin}`);
    cb(new Error("Not allowed by CORS"));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  exposedHeaders: ['Content-Type', 'Authorization'],
  preflightContinue: false,
  optionsSuccessStatus: 204
}));

app.use(express.json({ limit: "10mb" }));

// Request logger (prod: file only, dev: console)
app.use((req, _res, next) => {
  if (isProd) writeLog("INFO", `${req.method} ${req.path}`, { ip: req.ip });
  next();
});

// Rate limiters
const formLimiter  = rateLimit({ 
  windowMs: 1 * 60 * 1000, // 1 minute window
  max: 5000,  // Allow 5000 submissions per minute (83 per second) - handles high traffic
  message: { error: "Too many submissions, try later" },
  standardHeaders: true,
  legacyHeaders: false,
  // Skip rate limiting for successful requests to allow burst traffic
  skipSuccessfulRequests: false,
});
const loginLimiter = rateLimit({ 
  windowMs: 15 * 60 * 1000, 
  max: 20,  
  message: { error: "Too many login attempts" },
  standardHeaders: true,
  legacyHeaders: false,
});

// ── Routes ────────────────────────────────────────────────────────────────────
app.use("/api/auth",       loginLimiter, authRoutes);
app.use("/api/leads", (req, res, next) => {
  if (req.method === "POST" && req.path === "/") return formLimiter(req, res, next);
  next();
}, leadsRoutes);
app.use("/api/admins",     adminsRoutes);
app.use("/api/filters",    filtersRoutes);
app.use("/api/activities", activitiesRoutes);
app.use("/api/followups",  followupsRoutes);
app.use("/api/calllogs",   calllogsRoutes);
app.use("/api/reports",    reportsRoutes);
app.use("/api/statuses",        statusesRoutes);
app.use("/api/contact",         contactRoutes);
app.use("/api/institutes",      institutesRoutes);
app.use("/api/course-mappings", courseMappingsRoutes);
app.use("/api/student-admissions", (req, res, next) => {
  if (req.method === "POST" && req.path === "/") return formLimiter(req, res, next);
  next();
}, studentAdmissionsRoutes);
app.use("/api/student-applications-view", studentApplicationsView);

// Dynamic website content routes
app.use("/api/site-config",         siteConfigRoutes);
app.use("/api/gallery",             galleryRoutes);
app.use("/api/events",              eventsRoutes);
app.use("/api/website-activities",  websiteActivitiesRoutes);
app.use("/api/media-library",       mediaLibraryRoutes);

// Serve uploaded files as static
app.use("/uploads", express.static(path.join(process.cwd(), "src", "uploads")));

// Health check
app.get("/api/health", async (_req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ status: "ok", db: "connected", ts: new Date().toISOString(), v: "2" });
  } catch (e: any) {
    writeLog("ERROR", "Health check DB failed", { message: e.message });
    res.status(500).json({ status: "error", db: "disconnected", v: "2", err: e.message?.slice(0, 100) });
  }
});

// 404
app.use((_req, res) => res.status(404).json({ error: "Not found" }));

// Global error handler
app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
  writeLog("ERROR", `${req.method} ${req.path} — ${err.message}`, { stack: err.stack });
  res.status(err.status || 500).json({ error: isProd ? "Internal server error" : err.message });
});

// ── Seed default statuses ─────────────────────────────────────────────────────
const seedStatuses = async () => {
  try {
    const count = await prisma.leadStatusConfig.count();
    if (count > 0) return;
    await prisma.leadStatusConfig.createMany({
      data: [
        { label:"New Leads",      value:"new",            color:"#3b82f6", stage:"initial", order:0, isDefault:true },
        { label:"Contacted",      value:"contacted",      color:"#eab308", stage:"active",  order:0, isDefault:true },
        { label:"Interested",     value:"interested",     color:"#22c55e", stage:"active",  order:1, isDefault:true },
        { label:"Cold",           value:"cold",           color:"#06b6d4", stage:"active",  order:2, isDefault:true },
        { label:"Warm",           value:"warm",           color:"#f97316", stage:"active",  order:3, isDefault:true },
        { label:"Admitted",       value:"admitted",       color:"#a855f7", stage:"closed",  order:0, isDefault:true },
        { label:"Not Interested", value:"not_interested", color:"#ef4444", stage:"closed",  order:1, isDefault:true },
        { label:"Lost",           value:"lost",           color:"#6b7280", stage:"closed",  order:2, isDefault:true },
      ],
    });
    writeLog("INFO", "Default statuses seeded");
  } catch (e: any) {
    writeLog("ERROR", "Seed failed", { message: e.message });
  }
};

// ── Start ─────────────────────────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT || "5000");
app.listen(PORT, "0.0.0.0", async () => {
  writeLog("INFO", `Server running on port ${PORT} [${isProd ? "production" : "development"}]`);
  // Connect explicitly so engine initialises before first request
  try { await prisma.$connect(); writeLog("INFO", "DB connected"); } catch (e: any) { writeLog("ERROR", "DB connect failed", { message: e.message }); }
  await seedStatuses();
});
